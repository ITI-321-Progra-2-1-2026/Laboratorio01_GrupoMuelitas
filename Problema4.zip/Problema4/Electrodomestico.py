class Electrodomestico:


    def __init__(self, nombre, marca, modelo, precio, color, consumoE, peso):
        self.nombre = nombre
        self.marca = marca
        self.modelo = modelo
        self.precio = precio
        self.color = color
        self.consumoE = consumoE
        self.peso = peso

        # Validación consumo
        if consumoE not in ["A", "B", "C", "D", "E", "F"]:
            consumoE = "F"

        self.consumoE = consumoE

    def mostrar(self):
        print("Nombre:", self.nombre)
        print("Marca:", self.marca)
        print("Modelo:", self.modelo)
        print("Precio:", self.precio)
        print("Color:", self.color)
        print("Consumo:", self.consumoE)
        print("Peso:", self.peso)
