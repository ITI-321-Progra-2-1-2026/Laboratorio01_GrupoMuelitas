from Electrodomestico import Electrodomestico


class Refrigerador(Electrodomestico):

    def __init__(self, nombre, marca, modelo, precio,color,consumoE, peso, cantP, disenho,capacidad, freezer):
        super().__init__(nombre, marca, modelo, precio, color, consumoE, peso)

        self.cantP = cantP
        self.disenho = disenho
        self.capacidad = capacidad
        self.freezer = freezer


    def registrarRefrigerador(vecRefrigerador):

        for i in range(5):
            if vecRefrigerador[i] is None:

                print("---Registrando Refrigerador---")

                nombre = input("Nombre: ")
                marca = input("Marca: ")
                modelo = input("Modelo: ")
                precio = float(input("Precio: "))
                color = input("Color: ")
                consumoE = input("Consumo energético A-F: ")
                peso = float(input("Peso: "))
                cantP = int(input("Cantidad de puertas: "))
                disenho = int(input("Diseño en pulgadas: "))
                capacidad = int(input("Capacidad en pies cúbicos: "))
                freezer = input("Freezer (Superior/Inferior): ")

                vecRefrigerador[i] = Refrigerador(
                    nombre, marca, modelo, precio, color,
                    consumoE, peso,
                    cantP, disenho, capacidad, freezer
                )

                print("Refrigerador registrado correctamente ")
                return

        print("No hay espacio disponible ")

    def mostrarR(self):
        super().mostrar()

        print("Cantidad de puertas:", self.cantP)
        print("Diseño:", self.disenho)
        print("Capacidad:", self.capacidad)
        print("Freezer:", self.freezer)
        print("------------------------")
