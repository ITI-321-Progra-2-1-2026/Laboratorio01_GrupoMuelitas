from Electrodomestico import Electrodomestico


class Televisor(Electrodomestico): #Asi heredo en python
    def __init__(self,nombre, marca, modelo,precio,color, consumoE, peso,resolucion, aspecto, tamanhoP):
        #Aunque herede tengo que pasarle otra vez los atributos porque tiene un init
        super().__init__(nombre, marca,modelo, precio,color, consumoE, peso)#Aqui pongo los que son de la clase madre

        self.resolucion = resolucion
        self.aspecto = aspecto
        self.tamanhoP = tamanhoP



    def registrarTelevisor(vecTelevisor):
        for i in range(5):
            if vecTelevisor[i] is None:
                print("---Registrando Televisor---")

                nombre = input("Nombre: ")
                marca = input("Marca: ")
                modelo = input("Modelo: ")
                precio = float(input("Precio: "))
                color = input("Color: ")
                consumoE = input("Consumo energético A-F: ")
                peso = float(input("Peso: "))
                resolucion = input("Resolución: ")
                aspecto = input("Aspecto: ")
                tamanhoP = int(input("Tamaño en pulgadas: "))

                vecTelevisor[i] = Televisor(
                    nombre, marca, modelo, precio, color,
                    consumoE, peso,
                    resolucion, aspecto, tamanhoP
                )

                print("Televisor registrado correctamente ")
                return

        print("No hay espacio disponible ")

    def mostrarT(self):
        super().mostrar()
        print("Resolución:", self.resolucion)
        print("Aspecto:", self.aspecto)
        print("Tamaño:", self.tamanhoP)
        print("-------------------")