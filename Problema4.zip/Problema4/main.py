
from Televisor import Televisor
from Refrigerador import Refrigerador

if __name__ == "__main__":
    vecTelevisor=[None]*5
    vecRefrigerador=[None]*5

    # 3. Precargue cada uno de los vectores con 2 artículos

    vecTelevisor[0]= Televisor("Televisor", "Lg", "3AA", 123.222, "Negro", "A" , 23, "720p",
                               "16:9", 21)

    vecTelevisor[1] = Televisor("Televisor", "Samsung", "3AA", 123.222, "Blanco", "A" , 25, "720p",
                               "16:9", 21)

    vecRefrigerador[0] = Refrigerador("Refrigerador", "Samsung", "A6554", 123.455,"Gris", "B", 123, 1, 2, 18,
                                      "Superior")

    vecRefrigerador[1] = Refrigerador("Refrigerador", "Samsung", "A6554", 120.255,"Gris", "B", 123, 1, 2, 18,
                                      "Inferior")


    def menuPrincipal():
        opc = 0

        while opc != 3:
            print("--------Tienda--------")
            print("1. Registrar un artículo")
            print("2. Mostrar datos")
            print("3. Salir")

            opc = int(input("Seleccione una opción: "))

            if opc == 1:
                print("Seleccione el tipo de artículo")
                print("1. Televisor")
                print("2. Refrigerador")

                tipo = int(input("Seleccione una opción: "))

                if tipo == 1:
                    Televisor.registrarTelevisor(vecTelevisor)

                elif tipo == 2:
                    Refrigerador.registrarRefrigerador(vecRefrigerador)

                else:
                    print("Tipo inválido")

            elif opc == 2:
                print("---Televisores---")
                for tv in vecTelevisor:
                    if tv is not None:
                        tv.mostrar()

                print("\n---Refrigeradores ---")
                for r in vecRefrigerador:
                    if r is not None:
                        r.mostrar()

            elif opc == 3:
                print("Saliendo del programa...")

            else:
                print("Opción no válida")


    if __name__ == "__main__":
        menuPrincipal()