
from Receta import Receta
class Producto:

    #Constructor, en python es init
    def __init__(self, nombre, codigo ):
        self.nombre = nombre
        self.codigo = codigo
        self.Receta = Receta()
        self.Receta.agregarIngredientes()


    def setnombre(self, nombre):
        self.__nombre = nombre


    def setcodigo(self, codigo):
        self.__codigo = codigo