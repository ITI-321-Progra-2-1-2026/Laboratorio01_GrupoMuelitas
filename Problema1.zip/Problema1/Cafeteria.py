#Laboratorio 1
#Problema 1
#Grupo muelitas: Danna Jiménez Arias, Kaleth Morant, Félix

from Receta import Receta
from Producto import Producto

class Cafeteria:
    def __init__(self):
        self.__cafeteria = []


    if __name__ == "__main__":
        nombre = input("Ingrese el nombre del producto: ")
        codigo = input("Ingrese el código del producto: ")

        producto = Producto(nombre, codigo)

        print("\n-------Producto-------")
        print("Nombre:", producto.nombre)
        print("Código:", producto.codigo)
        producto.Receta.mostrarReceta()
