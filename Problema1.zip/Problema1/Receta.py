class Receta:
    def __init__(self):
        self.ingredientes = [] #creo el array para guardar las recetas

    def agregarIngredientes(self):
        nomIngrediente = []
        seguir= "s"
        while seguir == "S" or seguir == "s":
            nombre = input("Ingrese el nombre del ingrediente ")
            nomIngrediente.append(nombre)
            seguir = input("Desea registrar otro ingrediente? S/N")

        for nombre in nomIngrediente:
            cantidad = float(input(f"Ingrese la cantidad de {nombre} : "))
            unidad = input(f"Ingrese la unidad de medida de {nombre} : ") #f para dar formato y no usar +


            self.ingredientes.append({
                "nombre": nombre,
                "cantidad": cantidad,
                "unidad": unidad,
            })

        print("Receta registrada correctamente")




    def mostrarReceta(self):
        print("-------Receta-------")
        for ing in self.ingredientes: #recorro la lista
            print(f"Nombre:{ing['nombre']} - Cant:{ing['cantidad']} - U:{ing['unidad']}")

    def __del__(self):
        print("Imprimiendo receta...")
