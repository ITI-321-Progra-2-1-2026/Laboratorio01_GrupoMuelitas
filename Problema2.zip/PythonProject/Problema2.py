from dataclasses import dataclass, field
from typing import List, Dict


@dataclass(frozen=True)
class OpcionEscala:
    texto: str
    valor: int

@dataclass
class Escala:
    """TDA Escala: controla las opciones válidas para preguntas cerradas."""
    nombre: str
    opciones: List[OpcionEscala]

    def valores_validos(self) -> List[int]:
        return [op.valor for op in self.opciones]

    def existe_valor(self, valor: int) -> bool:
        return any(op.valor == valor for op in self.opciones)

    def texto_por_valor(self, valor: int) -> str:
        for op in self.opciones:
            if op.valor == valor:
                return op.texto
        raise ValueError(f"Valor {valor} no existe en la escala '{self.nombre}'.")

def escala_acuerdo() -> Escala:
    return Escala(
        "Acuerdo",
        [
            OpcionEscala("Muy de acuerdo", 4),
            OpcionEscala("De acuerdo", 3),
            OpcionEscala("Poco de acuerdo", 2),
            OpcionEscala("En desacuerdo", 1),
        ],
    )


def escala_calidad() -> Escala:
    return Escala(
        "Calidad",
        [
            OpcionEscala("Excelente", 6),
            OpcionEscala("Muy Bueno", 5),
            OpcionEscala("Bueno", 4),
            OpcionEscala("Regular", 3),
            OpcionEscala("Malo", 2),
            OpcionEscala("Muy malo", 1),
        ],
    )


def escala_si_no() -> Escala:
    return Escala(
        "Si/No",
        [
            OpcionEscala("Si", 1),
            OpcionEscala("No", 0),
        ],
    )


@dataclass
class Pregunta:
    enunciado: str

    def es_cerrada(self) -> bool:
        return False


@dataclass
class PreguntaCerrada(Pregunta):
    escala: Escala

    def es_cerrada(self) -> bool:
        return True

    def validar_respuesta(self, valor: int) -> None:
        if not self.escala.existe_valor(valor):
            raise ValueError(
                f"Respuesta inválida ({valor}) para '{self.enunciado}'. "
                f"Valores permitidos: {self.escala.valores_validos()} en escala '{self.escala.nombre}'."
            )


@dataclass
class PreguntaAbierta(Pregunta):
    pass


@dataclass
class Categoria:
    nombre: str
    preguntas: List[Pregunta] = field(default_factory=list)

    def agregar_pregunta(self, pregunta: Pregunta) -> None:
        self.preguntas.append(pregunta)



@dataclass
class InstrumentoEvaluacion:
    """Contiene categorías y preguntas (simula el documento base)."""
    titulo: str
    categorias: List[Categoria] = field(default_factory=list)

    def agregar_categoria(self, categoria: Categoria) -> None:
        self.categorias.append(categoria)

    def todas_las_preguntas(self) -> List[Pregunta]:
        preguntas = []
        for cat in self.categorias:
            preguntas.extend(cat.preguntas)
        return preguntas


@dataclass
class Docente:
    nombre: str


@dataclass
class Curso:
    nombre: str


@dataclass
class EvaluacionAplicada:
    """Registro de una evaluación a un docente para un curso en un año/periodo."""
    docente: Docente
    curso: Curso
    anio: int
    periodo: str
    instrumento: InstrumentoEvaluacion
    respuestas_cerradas: Dict[str, int] = field(default_factory=dict)  # enunciado -> valor
    respuestas_abiertas: Dict[str, str] = field(default_factory=dict)  # enunciado -> texto

    def responder_cerrada(self, pregunta: PreguntaCerrada, valor: int) -> None:
        pregunta.validar_respuesta(valor)
        self.respuestas_cerradas[pregunta.enunciado] = valor

    def responder_abierta(self, pregunta: PreguntaAbierta, texto: str) -> None:
        self.respuestas_abiertas[pregunta.enunciado] = texto.strip()

    def puntaje_total(self) -> int:
        return sum(self.respuestas_cerradas.values())

    def puntaje_maximo_posible(self) -> int:
        total = 0
        for p in self.instrumento.todas_las_preguntas():
            if isinstance(p, PreguntaCerrada):
                total += max(p.escala.valores_validos())
        return total

    def rendimiento_porcentaje(self) -> float:
        maximo = self.puntaje_maximo_posible()
        if maximo == 0:
            return 0.0
        return (self.puntaje_total() / maximo) * 100.0


def demo():
    instrumento = InstrumentoEvaluacion("Evaluación Docente - UTN")

    cat_personales = Categoria("Aspectos Personales")
    cat_profesionales = Categoria("Aspectos Profesionales")
    cat_intelectuales = Categoria("Aspectos Intelectuales")

    p1 = PreguntaCerrada("El docente muestra respeto hacia el estudiantado.", escala_acuerdo())
    p2 = PreguntaCerrada("La explicación de los temas fue clara.", escala_calidad())
    p3 = PreguntaCerrada("El docente entrega evaluaciones a tiempo.", escala_si_no())
    p4 = PreguntaAbierta("Comentarios adicionales sobre el docente:")

    cat_personales.agregar_pregunta(p1)
    cat_profesionales.agregar_pregunta(p2)
    cat_profesionales.agregar_pregunta(p3)
    cat_intelectuales.agregar_pregunta(p4)

    instrumento.agregar_categoria(cat_personales)
    instrumento.agregar_categoria(cat_profesionales)
    instrumento.agregar_categoria(cat_intelectuales)

    docente = Docente("María Fernanda Pizarro Chávez")
    curso = Curso("Plataformas Tecnológicas")
    evaluacion = EvaluacionAplicada(
        docente=docente,
        curso=curso,
        anio=2026,
        periodo="I-2026",
        instrumento=instrumento
    )
    evaluacion.responder_cerrada(p1, 4)  # Muy de acuerdo
    evaluacion.responder_cerrada(p2, 5)  # Muy Bueno
    evaluacion.responder_cerrada(p3, 1)  # Sí
    evaluacion.responder_abierta(p4, "Buen trato y domina los contenidos, pero puede mejorar el ritmo.")

    print("=== SALIDA DE EVALUACIÓN ===")
    print(f"Docente: {evaluacion.docente.nombre}")
    print(f"Curso: {evaluacion.curso.nombre}")
    print(f"Año/Periodo: {evaluacion.anio} / {evaluacion.periodo}")

    for pregunta in [p1, p2]:
        valor = evaluacion.respuestas_cerradas.get(pregunta.enunciado, None)
        texto = pregunta.escala.texto_por_valor(valor) if valor is not None else "Sin respuesta"
        print(f"- {pregunta.enunciado}")
        print(f"  Respuesta: {texto} (puntaje {valor})")

    print(f"Puntaje total (cerradas): {evaluacion.puntaje_total()} / {evaluacion.puntaje_maximo_posible()}")
    print(f"Rendimiento: {evaluacion.rendimiento_porcentaje():.2f}%")
    print("============================")


if __name__ == "__main__":
    demo()
