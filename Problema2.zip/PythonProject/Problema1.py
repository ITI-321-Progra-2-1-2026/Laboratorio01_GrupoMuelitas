
class Receta:
    def __init__(self, nombre):
        self.nombre = nombre
        self.items = []

    def agregar(self, ing, cant, unidad="ml"):
        self.items.append((ing, cant, unidad))

    def ver(self):
        if not self.items:
            return "(Sin ingredientes)"
        return "\n".join([f"- {i}: {c} {u}" for (i, c, u) in self.items])

    def __del__(self):
        print("Sacando receta del menú")


class Producto:
    def __init__(self, nombre, precio, receta, frio_caliente, simple_compuesto, con_alcohol, origen, proceso):
        self.nombre = nombre
        self.precio = precio
        self.receta = receta
        self.frio_caliente = frio_caliente
        self.simple_compuesto = simple_compuesto
        self.con_alcohol = con_alcohol
        self.origen = origen
        self.proceso = proceso

    def desc(self):
        alco = "con alcohol" if self.con_alcohol else "sin alcohol"
        return f"{self.nombre} ({self.frio_caliente}, {self.simple_compuesto}, {alco}) ₡{self.precio:.0f}"

    def ver_receta(self):
        return f"Receta: {self.receta.nombre}\n{self.receta.ver()}"

    @classmethod
    def desde_datos(cls, nombre, precio, frio_caliente, simple_compuesto, con_alcohol, origen, proceso, items, tipo):
        r = Receta(f"Receta de {nombre}")
        for ing, cant, unidad in items:
            r.agregar(ing, cant, unidad)
        return (Bebida if tipo == "bebida" else Postre)(
            nombre, precio, r, frio_caliente, simple_compuesto, con_alcohol, origen, proceso
        )


    @classmethod
    def desde_consola(cls):
        nombre = input("Nombre del producto: ")
        precio = float(input("Precio: "))
        tipo = input("Tipo (bebida/postre): ").lower()
        frio = input("Frío/Caliente: ").lower()
        simp = input("Simple/Compuesto: ").lower()
        alco = input("¿Alcohol? (s/n): ").lower() == "s"
        origen = input("Origen del café (CR): ")
        proceso = input("Proceso del grano: ")

        r = Receta(f"Receta de {nombre}")
        print("\nIngredientes (ENTER para terminar)")
        while True:
            ing = input("Ingrediente: ").strip()
            if ing == "":
                break
            cant = float(input("Cantidad: "))
            unidad = input("Unidad: ").strip() or "ml"
            r.agregar(ing, cant, unidad)

        return (Bebida if tipo == "bebida" else Postre)(
            nombre, precio, r, frio, simp, alco, origen, proceso
        )


class Bebida(Producto):
    def desc(self):
        return super().desc() + f" | Bebida | Origen: {self.origen} | Proceso: {self.proceso}"


class Postre(Producto):
    def desc(self):
        return super().desc() + f" | Postre | Origen café: {self.origen}"



class Menu:
    def __init__(self):
        self.vec = []

    def agregar(self, p):
        self.vec.append(p)

    def listar(self):
        print("\n===== MENÚ =====")
        for i, p in enumerate(self.vec, 1):
            print(f"{i}. {p.desc()}")

    def buscar(self, nombre):
        nombre = nombre.lower()
        for p in self.vec:
            if p.nombre.lower() == nombre:
                return p
        return None

def main():
    m = Menu()

    m.agregar(Producto.desde_datos(
        "Latte Vainilla", 2200, "caliente", "compuesto", False, "Tarrazú", "Lavado",
        [("Espresso", 30, "ml"), ("Leche", 180, "ml"), ("Vainilla", 10, "ml")],
        "bebida"
    ))

    m.agregar(Producto.desde_datos(
        "Affogato", 2800, "frío", "compuesto", False, "Tres Ríos", "Honey",
        [("Helado", 120, "g"), ("Espresso", 30, "ml"), ("Chocolate", 15, "g")],
        "postre"
    ))

    m.listar()
    print("\n--- AGREGAR NUEVO PRODUCTO ---")
    nuevo = Producto.desde_consola()
    m.agregar(nuevo)

    print("\n--- MENÚ ACTUALIZADO ---")
    m.listar()

    print("\nCerrando sistema...")
    del m


if __name__ == "__main__":
    main()
